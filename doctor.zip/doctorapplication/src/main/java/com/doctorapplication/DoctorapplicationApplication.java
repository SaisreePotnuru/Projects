package com.doctorapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorapplicationApplication.class, args);
	}

}
