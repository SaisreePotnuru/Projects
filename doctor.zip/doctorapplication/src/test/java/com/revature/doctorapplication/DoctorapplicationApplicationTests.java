package com.revature.doctorapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
